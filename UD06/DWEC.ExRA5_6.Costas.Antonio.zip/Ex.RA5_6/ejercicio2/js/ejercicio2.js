// Antonio Costas Salazar

function manejadorClick(e) {

}

function entroDiv(e) {

}

function salgoDiv(e) {

}

function escribir(e) {

}