// Nombre y apellidos

function calculosMultiples
